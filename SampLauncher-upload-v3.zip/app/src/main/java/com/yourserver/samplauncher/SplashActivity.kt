package com.yourserver.samplauncher

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class SplashActivity : AppCompatActivity() {

    // ==========================================================
    // ЗДЕСЬ НУЖНО УКАЗАТЬ ССЫЛКУ НА version.json
    // ==========================================================
    // Как только выложите архив с модами (mods.zip) и файл version.json
    // в GitHub Releases своего репозитория, вставьте сюда прямую ссылку
    // на version.json, например:
    // "https://github.com/user/repo/releases/latest/download/version.json"
    //
    // Пока ссылка пустая — экран загрузки пропускается, лаунчер сразу
    // открывает главное меню (ничего не сломается, просто моды не качаются).
    private val MODS_VERSION_URL = ""
    // ==========================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        if (MODS_VERSION_URL.isBlank()) {
            goToMenu()
            return
        }

        val prefs = getSharedPreferences("cache", MODE_PRIVATE)
        val localVersion = prefs.getInt("mods_version", 0)

        lifecycleScope.launch(Dispatchers.IO) {
            val result = try {
                val client = OkHttpClient()
                val request = Request.Builder().url(MODS_VERSION_URL).build()
                client.newCall(request).execute().use { response ->
                    val body = response.body?.string() ?: throw Exception("empty body")
                    val json = JSONObject(body)
                    Pair(json.getInt("version"), json.getString("url"))
                }
            } catch (e: Exception) {
                null
            }

            withContext(Dispatchers.Main) {
                if (result != null && result.first > localVersion) {
                    startActivity(
                        Intent(this@SplashActivity, DownloadActivity::class.java)
                            .putExtra("url", result.second)
                            .putExtra("version", result.first)
                    )
                    finish()
                } else {
                    // Версия актуальна, либо сервер с version.json недоступен —
                    // не блокируем пользователя, пускаем в меню на локальном кэше.
                    goToMenu()
                }
            }
        }
    }

    private fun goToMenu() {
        startActivity(Intent(this, MainMenuActivity::class.java))
        finish()
    }
}
