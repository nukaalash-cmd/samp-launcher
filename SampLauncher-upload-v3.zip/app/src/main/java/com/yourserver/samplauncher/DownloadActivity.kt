package com.yourserver.samplauncher

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class DownloadActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var percentText: TextView
    private lateinit var statusText: TextView
    private lateinit var retryButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_download)

        progressBar = findViewById(R.id.downloadProgress)
        percentText = findViewById(R.id.tvDownloadPercent)
        statusText = findViewById(R.id.tvDownloadStatus)
        retryButton = findViewById(R.id.btnRetry)

        val url = intent.getStringExtra("url") ?: run { goToMenu(); return }
        val version = intent.getIntExtra("version", 0)

        download(url, version)
    }

    private fun download(url: String, version: Int) {
        retryButton.visibility = View.GONE
        statusText.text = getString(R.string.download_title)

        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { showError(url, version) }
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    runOnUiThread { showError(url, version) }
                    return
                }

                try {
                    val body = response.body ?: throw IOException("empty body")
                    val total = body.contentLength()
                    var downloaded = 0L
                    val zipFile = File(filesDir, "mods.zip")

                    body.byteStream().use { input ->
                        FileOutputStream(zipFile).use { output ->
                            val buffer = ByteArray(8192)
                            var read: Int
                            while (input.read(buffer).also { read = it } != -1) {
                                output.write(buffer, 0, read)
                                downloaded += read
                                val percent = if (total > 0) (downloaded * 100 / total).toInt() else 0
                                runOnUiThread {
                                    progressBar.progress = percent
                                    percentText.text = "$percent%"
                                }
                            }
                        }
                    }

                    runOnUiThread { statusText.text = getString(R.string.download_unpacking) }
                    unzip(zipFile, File(filesDir, "mods"))

                    getSharedPreferences("cache", MODE_PRIVATE).edit()
                        .putInt("mods_version", version).apply()

                    runOnUiThread { goToMenu() }
                } catch (e: Exception) {
                    runOnUiThread { showError(url, version) }
                }
            }
        })
    }

    private fun showError(url: String, version: Int) {
        statusText.text = getString(R.string.download_error)
        retryButton.visibility = View.VISIBLE
        retryButton.setOnClickListener { download(url, version) }
    }

    private fun unzip(zipFile: File, targetDir: File) {
        targetDir.mkdirs()
        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        zipFile.delete()
    }

    private fun goToMenu() {
        startActivity(Intent(this, MainMenuActivity::class.java))
        finish()
    }
}
