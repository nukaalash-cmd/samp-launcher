package com.yourserver.samplauncher

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

class MainActivity : AppCompatActivity() {

    // ==========================================================
    // ЗДЕСЬ НУЖНО УКАЗАТЬ ДАННЫЕ ВАШЕЙ ИГРЫ / МОДА
    // ==========================================================

    // Package name готового мобильного клиента "SA-MP Launcher" (разработчик Jekmant).
    // Этот клиент сам управляет GTA SA + подключением к SA-MP серверам.
    private val GAME_PACKAGE_NAME = "ru.unisamp_mobile.launcher"

    // Путь к конфиг-файлу, который читает ваш мод при старте
    // (обычно что-то вроде samp.cfg / server.cfg внутри папки мода на внешнем хранилище)
    // TODO: замените путь на тот, что использует ваш конкретный мод
    private fun getConfigFile(): File {
        val baseDir = getExternalFilesDir(null) ?: filesDir
        return File(baseDir, "SAMP/samp.cfg") // TODO: скорректируйте путь под свой мод
    }

    // Сервер по умолчанию — впишите свои значения
    private val DEFAULT_IP = "127.0.0.1"   // TODO: IP вашего сервера
    private val DEFAULT_PORT = "7777"      // TODO: порт вашего сервера

    // ==========================================================

    private lateinit var prefs: SharedPreferences
    private lateinit var etNickname: EditText
    private lateinit var etIp: EditText
    private lateinit var etPort: EditText
    private lateinit var tvStatus: TextView
    private lateinit var dotStatus: View
    private lateinit var btnPlay: View

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("launcher_prefs", MODE_PRIVATE)

        etNickname = findViewById(R.id.etNickname)
        etIp = findViewById(R.id.etIp)
        etPort = findViewById(R.id.etPort)
        tvStatus = findViewById(R.id.tvStatus)
        dotStatus = findViewById(R.id.dotStatus)
        btnPlay = findViewById(R.id.btnPlay)

        // Подставляем сохранённые (или дефолтные) значения
        etNickname.setText(prefs.getString("nickname", ""))
        etIp.setText(prefs.getString("ip", DEFAULT_IP))
        etPort.setText(prefs.getString("port", DEFAULT_PORT))

        btnPlay.setOnClickListener { onPlayClicked() }

        checkServerStatus()
    }

    private fun onPlayClicked() {
        val nickname = etNickname.text.toString().trim()
        val ip = etIp.text.toString().trim()
        val port = etPort.text.toString().trim()

        if (nickname.isEmpty() || ip.isEmpty() || port.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_fields), Toast.LENGTH_SHORT).show()
            return
        }

        // Сохраняем настройки
        prefs.edit()
            .putString("nickname", nickname)
            .putString("ip", ip)
            .putString("port", port)
            .apply()

        // ВАЖНО: этот файл читает только НАШ лаунчер (для запоминания полей).
        // Клиент "SA-MP Launcher" использует свой собственный формат хранения
        // серверов/настроек и не подхватит ник/IP отсюда автоматически — при
        // первом заходе в него нужно будет добавить сервер (по IP) вручную
        // внутри самого клиента, либо через раздел "Favorites"/"Избранное".
        writeConfig(nickname, ip, port)

        // Запускаем игру
        launchGame()
    }

    private fun writeConfig(nickname: String, ip: String, port: String) {
        try {
            val configFile = getConfigFile()
            configFile.parentFile?.mkdirs()

            // Формат ниже — ПРИМЕР в стиле классического samp.cfg.
            // TODO: замените на формат, который реально читает ваш мод-клиент.
            val content = buildString {
                appendLine("nickname=$nickname")
                appendLine("ip=$ip")
                appendLine("port=$port")
            }

            configFile.writeText(content)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось записать конфиг: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchGame() {
        val launchIntent = packageManager.getLaunchIntentForPackage(GAME_PACKAGE_NAME)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            // Клиент ещё не установлен — открываем страницу установки в Google Play
            openPlayStore()
        }
    }

    private fun openPlayStore() {
        Toast.makeText(
            this,
            "Сначала установите клиент SA-MP Mobile — открываю Google Play",
            Toast.LENGTH_LONG
        ).show()
        try {
            val marketIntent = Intent(
                Intent.ACTION_VIEW,
                android.net.Uri.parse("market://details?id=$GAME_PACKAGE_NAME")
            )
            marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(marketIntent)
        } catch (e: Exception) {
            val webIntent = Intent(
                Intent.ACTION_VIEW,
                android.net.Uri.parse("https://play.google.com/store/apps/details?id=$GAME_PACKAGE_NAME")
            )
            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(webIntent)
        }
    }

    // Простая проверка доступности сервера (пинг по TCP) в фоновом потоке
    private fun checkServerStatus() {
        tvStatus.text = getString(R.string.status_checking)

        Thread {
            val ip = prefs.getString("ip", DEFAULT_IP) ?: DEFAULT_IP
            val port = (prefs.getString("port", DEFAULT_PORT) ?: DEFAULT_PORT).toIntOrNull() ?: 7777

            val isOnline = try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(ip, port), 3000)
                    true
                }
            } catch (e: Exception) {
                false
            }

            mainHandler.post { updateStatusUi(isOnline) }
        }.start()
    }

    private fun updateStatusUi(isOnline: Boolean) {
        if (isOnline) {
            tvStatus.text = getString(R.string.status_online)
            dotStatus.setBackgroundResource(R.drawable.dot_status)
            dotStatus.backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(this, R.color.status_online)
                )
        } else {
            tvStatus.text = getString(R.string.status_offline)
            dotStatus.backgroundTintList =
                android.content.res.ColorStateList.valueOf(
                    androidx.core.content.ContextCompat.getColor(this, R.color.status_offline)
                )
        }
    }
}
