package com.yourserver.samplauncher

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

class MainMenuActivity : AppCompatActivity() {

    // ==========================================================
    // ЗДЕСЬ НУЖНО УКАЗАТЬ ДАННЫЕ ВАШЕЙ ИГРЫ / МОДА
    // ==========================================================

    // Package name реального установленного клиента "SA-MP Launcher".
    private val GAME_PACKAGE_NAME = "com.samp.x1y2z"

    // Сервер зафиксирован (один сервер, без выбора)
    private val SERVER_IP = "141.95.190.146"
    private val SERVER_PORT = 1317

    // Путь к конфиг-файлу, который читает ваш мод при старте.
    // TODO: замените путь на тот, что использует ваш конкретный мод.
    private fun getConfigFile(): File {
        val baseDir = getExternalFilesDir(null) ?: filesDir
        return File(baseDir, "SAMP/samp.cfg")
    }

    // ==========================================================

    private lateinit var prefs: SharedPreferences
    private lateinit var etNickname: EditText
    private lateinit var tvStatus: TextView
    private lateinit var dotStatus: View

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("launcher_prefs", MODE_PRIVATE)

        etNickname = findViewById(R.id.etNickname)
        tvStatus = findViewById(R.id.tvStatus)
        dotStatus = findViewById(R.id.dotStatus)
        val btnPlay = findViewById<View>(R.id.btnPlay)

        etNickname.setText(prefs.getString("nickname", ""))

        btnPlay.setOnClickListener { onPlayClicked() }

        checkServerStatus()
    }

    private fun onPlayClicked() {
        val nickname = etNickname.text.toString().trim()

        if (nickname.isEmpty()) {
            Toast.makeText(this, getString(R.string.error_fields), Toast.LENGTH_SHORT).show()
            return
        }

        prefs.edit().putString("nickname", nickname).apply()

        // ВАЖНО: этот файл читает только НАШ лаунчер (для запоминания ника).
        // Клиент "SA-MP Launcher" использует свой собственный формат хранения
        // серверов и не подхватит ник/IP отсюда автоматически — при первом
        // заходе в него нужно будет добавить сервер вручную через Favorites.
        writeConfig(nickname, SERVER_IP, SERVER_PORT.toString())

        launchGame()
    }

    private fun writeConfig(nickname: String, ip: String, port: String) {
        try {
            val configFile = getConfigFile()
            configFile.parentFile?.mkdirs()

            val content = buildString {
                appendLine("nickname=$nickname")
                appendLine("ip=$ip")
                appendLine("port=$port")
            }

            configFile.writeText(content)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось записать конфиг: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchGame() {
        val launchIntent = packageManager.getLaunchIntentForPackage(GAME_PACKAGE_NAME)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            openPlayStore()
        }
    }

    private fun openPlayStore() {
        Toast.makeText(
            this,
            "Сначала установите клиент SA-MP Mobile — открываю Google Play",
            Toast.LENGTH_LONG
        ).show()
        try {
            val marketIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=$GAME_PACKAGE_NAME")
            )
            marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(marketIntent)
        } catch (e: Exception) {
            val webIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$GAME_PACKAGE_NAME")
            )
            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(webIntent)
        }
    }

    private fun checkServerStatus() {
        tvStatus.text = getString(R.string.status_checking)

        Thread {
            val isOnline = try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(SERVER_IP, SERVER_PORT), 3000)
                    true
                }
            } catch (e: Exception) {
                false
            }

            mainHandler.post { updateStatusUi(isOnline) }
        }.start()
    }

    private fun updateStatusUi(isOnline: Boolean) {
        val colorRes = if (isOnline) R.color.status_online else R.color.status_offline
        tvStatus.text = getString(if (isOnline) R.string.status_online else R.string.status_offline)
        dotStatus.backgroundTintList =
            android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, colorRes))
    }
}
